# doom.nats:mob/biome/lush_caves/water_ambient —— minecraft:lush_caves · water_ambient（权重和 25，1 条）

# ---- 结构 spawn_overrides 优先（原版 ChunkGenerator.getMobsAt：命中即整表替换；空表 = 该类别无物种）----
execute if predicate doom.nats:spawn/in_ancient_city run return 0
execute if predicate doom.nats:spawn/in_trial_chambers run return 0

scoreboard players set #wsum doom.nats 25
scoreboard players operation $rng doom.nats %= #wsum doom.nats
execute if score $rng doom.nats matches 0..24 run scoreboard players set $sel.ok doom.nats 1
execute if score $rng doom.nats matches 0..24 run data merge storage doom.nats:sel {type:"minecraft:tropical_fish",slug:"tropical_fish",cat:"water_ambient",min:8,max:8,nbt:{Tags:["doom.nats.spawned","doom.nats.cat.water_ambient"]}}
execute if score $rng doom.nats matches 0..24 run scoreboard players set $sel.rule doom.nats 31
execute if score $rng doom.nats matches 0..24 run scoreboard players set $sel.place doom.nats 3
execute if score $rng doom.nats matches 0..24 run scoreboard players set $sel.light doom.nats 0
execute if score $rng doom.nats matches 0..24 run scoreboard players set $sel.tag doom.nats 0
execute if score $rng doom.nats matches 0..24 run scoreboard players set $sel.grp1 doom.nats 1
execute if score $rng doom.nats matches 0..24 run scoreboard players set $sel.wide doom.nats 0
execute if score $rng doom.nats matches 0..24 run scoreboard players set $sel.wide2 doom.nats 0
execute if score $rng doom.nats matches 0..24 run scoreboard players set $sel.tall doom.nats 0
execute if score $rng doom.nats matches 0..24 run scoreboard players set $sel.cluster doom.nats 8
