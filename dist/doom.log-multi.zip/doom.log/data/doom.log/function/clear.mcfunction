# doom.log:clear —— 清空（实现见 history/clear）
function doom.log:history/clear
