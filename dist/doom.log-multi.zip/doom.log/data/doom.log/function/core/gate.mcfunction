
# doom.log:core/gate —— 闸门①：**阈值**
# 调用：function doom.log:core/gate {rank:1}    （rank：error=1 / warn=2 / info=3）
#
# 语义：#min dl.log = 最低要播到哪一档（1 = 只放 error，2 = +warn，3 = 全放，默认 3）。
#   档位序 ≤ #min 才放行。⇒ 「运维时只留错误、开发时全开」只需改一个分数：
#       /scoreboard players set #min dl.log 1
#   bs.log 没有阈值，只能靠"命名空间 × tag × severity"的组合 tag 逐个静音。
#
# 产出：#emit_rank dl.log = 0 / 1
scoreboard players set #emit_rank dl.log 0
$execute if score #min dl.log matches $(rank).. run scoreboard players set #emit_rank dl.log 1
