
# doom.log:core/dedupe —— 闸门②：**同 code 冷却**（防每 tick 刷屏）+ by_code 记账
# 调用：function doom.log:core/dedupe {code:"E201"}
#
# 产出：#emit_code dl.log = 1 放行 / 0 抑制
#
# 为什么这一层必须在 API 入口（宏）而不是 severity 里：**code 是运行期字符串**，
#   而 storage 路径不支持动态键 —— 只有宏参数能把它拼进路径。
#   bs.log 完全没有去重：同一个错误每 tick 触发就每 tick 刷一地。
#
# 记账与播报分离：冷却只影响"出声"，次数/时间戳/最近消息**照记**（历史与计数器在 history/record + 这里）。
scoreboard players set #emit_code dl.log 1
execute store result score #now dl.log run time query gametime
# 读该 code 上次播报的游戏刻（没有就是不抑制）
scoreboard players set #prev dl.log 0
$execute if data storage doom.log:data by_code."$(code)".t store result score #prev dl.log run data get storage doom.log:data by_code."$(code)".t
scoreboard players operation #gap dl.log = #now dl.log
scoreboard players operation #gap dl.log -= #prev dl.log
execute if score #prev dl.log matches 1.. if score #gap dl.log < #cd dl.log run scoreboard players set #emit_code dl.log 0
# 盖时间戳：下一次的"上次播报"就是它
$execute store result storage doom.log:data by_code."$(code)".t int 1 run scoreboard players get #now dl.log
# 次数：读出来 +1 再写回（storage 的数字没法原地自增）
scoreboard players set #c dl.log 0
$execute if data storage doom.log:data by_code."$(code)".n store result score #c dl.log run data get storage doom.log:data by_code."$(code)".n
scoreboard players add #c dl.log 1
$execute store result storage doom.log:data by_code."$(code)".n int 1 run scoreboard players get #c dl.log
# 最近一次的长相（dump 用）
$data modify storage doom.log:data by_code."$(code)".message set from storage doom.log:in message
