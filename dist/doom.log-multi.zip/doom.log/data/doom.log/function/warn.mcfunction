
# doom.log:warn —— 上报一条 **警告**（推荐入口）
#
# 调用（**两个键都必须写**）：function doom.log:warn {{code:"E201", message:"…"}}
#   · 宏参数缺一个 ⇒ **整个函数体被静默放弃**（引擎行为，本项目已钉）
#   · 参数值里**别带引号**：宏替换会剥掉 NBT 字符串引号；模板里的引号已经写好，你给裸文本
#   · 想标注"谁报的"：本入口会把 in.path 复位成默认；需要精确路径请用**分区入口**：
#       data modify storage doom.log:in.path set value "doom.xxx:yyy"
#       function #doom.log:warn
#     （分区入口 = 自己写契约再调标签，会跳过本入口的去重与 by_code 记账 —— 见 README）
$data modify storage doom.log:in code set value "$(code)"
$data modify storage doom.log:in message set value "$(message)"
data modify storage doom.log:in path set value "(未指定)"
$function doom.log:core/dedupe {code:"$(code)"}
function #doom.log:warn
