# doom.log:dump —— 看汇总（实现见 history/show）
function doom.log:history/show
