
# doom.log:__help__ —— 本地手册（bs.log 的 help 只给一个网址，本包不依赖联网）
tellraw @s [{"text":"===== doom.log 手册 =====","color":"gold"}]
tellraw @s [{"text":"上报  ","color":"gray"},{"text":"function doom.log:error {code:\"E201\", message:\"…\"}","color":"white"}]
tellraw @s [{"text":"        ","color":"gray"},{"text":"warn / info 同形；code 两端都必填（宏缺参 ⇒ 整条被静默放弃）","color":"dark_gray"}]
tellraw @s [{"text":"查看  ","color":"gray"},{"text":"doom.log:dump","color":"white"},{"text":"（计数 + 每个 code 的次数/最近时刻 + 最后一条）","color":"dark_gray"}]
tellraw @s [{"text":"清空  ","color":"gray"},{"text":"doom.log:clear","color":"white"}]
tellraw @s [{"text":"阈值  ","color":"gray"},{"text":"/scoreboard players set #min dl.log 1","color":"white"},{"text":"（1=只 error / 2=+warn / 3=全放）","color":"dark_gray"}]
tellraw @s [{"text":"静音  ","color":"gray"},{"text":"tag @s add de.mute.warn","color":"white"},{"text":"（warn）/ de.mute.info（info）；error 不可静音","color":"dark_gray"}]
tellraw @s [{"text":"编码  ","color":"gray"},{"text":"E1xx 配置 · E2xx 并发 · E3xx 持久层 · E4xx 物品/NBT · E5xx 调度 · E9xx 其它","color":"white"}]
