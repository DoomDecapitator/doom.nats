
# doom.log:__load__
#
# 三层 storage（与 bs.log 同构）：
#   doom.log:in     —— **调用契约**：code / message / path / gt / dt
#   doom.log:const  —— 常量（冷却窗口、历史上限、以及做除法用的字面量分数）
#   doom.log:data   —— 状态：history[] / by_code / last
#
# doomtest-ignore: E2 —— 加载期设置，不涉及"逐实体流水线跨行共享状态"。
scoreboard objectives add dl.log dummy
scoreboard players set #min dl.log 3
scoreboard players set #emit_code dl.log 1
scoreboard players set #emit_rank dl.log 1
scoreboard players set #total dl.log 0
scoreboard players set #error dl.log 0
scoreboard players set #warn dl.log 0
scoreboard players set #info dl.log 0
scoreboard players set #n dl.log 0
scoreboard players set #c dl.log 0
scoreboard players set #now dl.log 0
scoreboard players set #prev dl.log 0
scoreboard players set #last dl.log 0
scoreboard players set #gap dl.log 0
scoreboard players set #cd dl.log 0
scoreboard players set #cap dl.log 0
# 常量：÷ 与比较的右操作数必须是**计分板持有者**，字面量写不进去（本项目已钉）
data modify storage doom.log:const cfg set value {cooldown:300, cap:20}
execute store result score #cd dl.log run data get storage doom.log:const cfg.cooldown
execute store result score #cap dl.log run data get storage doom.log:const cfg.cap
execute unless data storage doom.log:data history run data modify storage doom.log:data history set value []
tellraw @a [{"text":"[doom.log] loaded","color":"dark_gray"}]
