
# doom.log:history/record —— 追加一条历史并维护计数（**无论是否播报都会跑**，由标签挂在最后）
#
# 结构照 bs.log（环形缓冲 + 上限），但不用它的两个手法：
#   · 不用 `history[-1]`（负索引是否合法本项目没验证过）—— 先在 tmp 里拼好整条，再 append
#   · 不用常驻 text_display 存"已格式化的 JSON 文本" —— 本包的消息是纯字符串，storage 足够
# ⚠ 第一行必须用 `set value {}`（创建或覆盖都成功）——**不能**先 `data remove`：
#   删一个还不存在的路径会失败，而失败会带走本函数剩下的所有行 ⇒ 历史与计数静默全丢。
#   （这条是 2026-09-26 debug 阶段逐行过契约时抓出来的；suite/log_core 的 ①c/①d 也会盯它。）
data modify storage doom.log:tmp entry set value {}
data modify storage doom.log:tmp entry.code set from storage doom.log:in code
data modify storage doom.log:tmp entry.message set from storage doom.log:in message
data modify storage doom.log:tmp entry.path set from storage doom.log:in path
data modify storage doom.log:tmp entry.gt set from storage doom.log:in gt
data modify storage doom.log:tmp entry.dt set from storage doom.log:in dt
data modify storage doom.log:data history append from storage doom.log:tmp entry
data modify storage doom.log:data last set from storage doom.log:tmp entry
data remove storage doom.log:tmp entry
# 环形上限：超过就丢最老的（列表长度可以直接用 data get 数出来，见易错点 §2.3）
execute store result score #n dl.log run data get storage doom.log:data history
# 环形上限：严格收到 cap 以内（可能一次丢多条 → 递归 trim）
execute if score #n dl.log > #cap dl.log run function doom.log:history/trim
scoreboard players add #total dl.log 1
