# doom.log:history/trim —— 把历史严格收到 #cap 以内（一次可能丢多条，递归到不超为止）
#
# 为什么不是"一次丢一条"：cap 被临时压到 1 时，若历史已有 N 条，只丢一条仍超上限 ⇒
#   套件断言"cap=1 只留最新一条"会红（2026-10-01 实测）。原注释写的是"超过就丢最老的"，
#   只对"每次只加一条、且起始就在上限内"成立；严格语义应当递归裁到 <= cap。
data remove storage doom.log:data history[0]
execute store result score #n dl.log run data get storage doom.log:data history
execute if score #n dl.log > #cap dl.log run function doom.log:history/trim
