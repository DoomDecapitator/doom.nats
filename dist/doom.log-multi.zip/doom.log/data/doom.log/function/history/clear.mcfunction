
# doom.log:history/clear —— 清空历史与计数（doom.log:clear 的实现）
# ⚠ 三条 remove 都要 `if data` 守住：删不存在的键会失败并带走后面（含最后那行重建 history）
execute if data storage doom.log:data history run data remove storage doom.log:data history
execute if data storage doom.log:data by_code run data remove storage doom.log:data by_code
execute if data storage doom.log:data last run data remove storage doom.log:data last
data modify storage doom.log:data history set value []
scoreboard players set #total dl.log 0
scoreboard players set #error dl.log 0
scoreboard players set #warn dl.log 0
scoreboard players set #info dl.log 0
scoreboard players set #n dl.log 0
scoreboard players set #last dl.log 0
tellraw @s [{"text":"[doom.log] 历史与计数已清空。","color":"dark_gray"}]
