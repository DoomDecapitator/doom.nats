
# doom.log:history/show —— 汇总视图（doom.log:dump 的实现）
tellraw @s [{"text":"===== doom.log 汇总 =====","color":"gold"}]
tellraw @s [{"text":"总计 ","color":"gray"},{"score":{"name":"#total","objective":"dl.log"},"color":"white"},{"text":"   error ","color":"red"},{"score":{"name":"#error","objective":"dl.log"},"color":"red"},{"text":"   warn ","color":"gray"},{"score":{"name":"#warn","objective":"dl.log"},"color":"yellow"},{"text":"   info ","color":"gray"},{"score":{"name":"#info","objective":"dl.log"},"color":"white"},{"text":"   阈值 #min = ","color":"gray"},{"score":{"name":"#min","objective":"dl.log"},"color":"white"},{"text":"（1=只 error / 2=+warn / 3=全放）","color":"dark_gray"}]
tellraw @s [{"text":"每个 code = ","color":"gray"},{"nbt":"by_code","storage":"doom.log:data","color":"white"}]
tellraw @s [{"text":"最后一条 = ","color":"gray"},{"nbt":"last","storage":"doom.log:data","color":"white"}]
tellraw @s [{"text":"判读：by_code 里出现过的 code 就是「踩过的坑清单」，n = 次数、t = 最近一次的游戏刻、message = 最近一次的原文。" ,"color":"aqua"}]
