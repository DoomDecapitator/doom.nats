
# doom.log:time/stamp —— 打时间戳（标签在 severity 之前调用它）
#
# 产出（写进契约 storage doom.log:in）：
#   gt = 当前游戏刻
#   dt = 距**上一条日志**过了多少 tick（第一条记 0）
#
# 设计取舍：bs.log 从 gametime 自己算 h:m:s，并额外挂一个**每秒跑一次**的 schedule 维护时钟字符串；
#   本包直接用"游戏刻 + 与上一条的间隔" —— 读日志时本来就是对着 latest.log 的游戏事件看，
#   这一对数字比墙上时间更好对齐，还省掉了那个常驻任务。
execute store result score #now dl.log run time query gametime
scoreboard players operation #gap dl.log = #now dl.log
scoreboard players operation #gap dl.log -= #last dl.log
execute if score #last dl.log matches 0 run scoreboard players set #gap dl.log 0
execute store result storage doom.log:in gt int 1 run scoreboard players get #now dl.log
execute store result storage doom.log:in dt int 1 run scoreboard players get #gap dl.log
scoreboard players operation #last dl.log = #now dl.log
