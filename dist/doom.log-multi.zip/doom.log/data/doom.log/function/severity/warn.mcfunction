# doom.log:severity/warn —— 组装并广播一条 **警告** 消息
#
# 由标签 `#doom.log:warn` 拉起（**不要直接调**）。跑到这里时：
#   · doom.log:time/stamp 已经填好 in.gt / in.dt
#   · doom.log:core/dedupe（api 入口里）已经算好 #emit_code
#   · 本文件的 core/gate 会再算 #emit_rank（阈值）
# 两个开关都为 1 才出声；**记账不受影响** —— 标签上还挂着 history/record，无论播不播都会记。
#
# ⚠ 这里用 `return 0` 提前收工是安全的：return 只结束**本函数**，
#   标签会继续往下跑 history/record（bs.log 同款结构，别改成整链中断）。

function doom.log:core/gate {rank:2}

# 闸门：阈值（#min dl.log）与冷却（#emit_code）都放行才播
# 档位计数（记账，跟播不播无关）
scoreboard players add #warn dl.log 1

execute unless score #emit_rank dl.log matches 1 run return 0
execute unless score #emit_code dl.log matches 1 run return 0

tellraw @a[tag=!de.mute.warn] [{"text":"[doom.log] ","color":"dark_gray"},{"text":"⚠ ","color":"#F3B512"},{"text":"警告 ","color":"#F3B512","bold":true},{"nbt":"code","storage":"doom.log:in","color":"gold"},{"text":"  ","color":"dark_gray"},{"nbt":"message","storage":"doom.log:in","color":"white"},{"text":"  ⓘ","color":"dark_gray","hover_event":{"action":"show_text","value":[{"text":"警告","color":"#F3B512"},{"text":"  · 游戏刻 ","color":"gray"},{"nbt":"gt","storage":"doom.log:in"},{"text":"  · 距上条日志 ","color":"gray"},{"nbt":"dt","storage":"doom.log:in"},{"text":" tick\n","color":"gray"},{"text":"报告者 ","color":"gray"},{"nbt":"path","storage":"doom.log:in"},{"text":"\n","color":"dark_gray"},{"text":"同一 code 在冷却窗口内重复上报只记账、不重复播（窗口见 doom.log:const cfg.cooldown）","color":"dark_gray"}]}}]


# 本档可被玩家自静音：`tag @s add de.mute.warn`。
# bs.log 用的是「命名空间 × tag × severity」三维组合（每个 severity 文件里 20 条 tag 判断）；
# 本包只有一个作者一个全家桶，砍成**档位级一维** —— 够用，且不会随包数组合爆炸。
