# doom.log — Doom 全家桶的统一报错通道

> 结构照 bookshelf 的 `bs.log`：**函数标签即 API**、三层 storage（`in` 契约 / `const` 常量 / `data` 状态）、
> `time → severity → history` 三段式流水线。
> 但砍掉了它的常驻实体、forceload、每秒 schedule 与三维静音矩阵，补上了它没有的**去重**与**阈值**。

## 结构

```
调用方
  │  function doom.log:error {code:"E201", message:"…"}      ← 推荐入口（宏）
  ▼
doom.log:error              api 入口：写契约 + 跑冷却闸门 + 转交标签
  │  function #doom.log:error                                ← 标签 = 真正的流水线
  ▼
├─ doom.log:time/stamp      打时间戳（写 in.gt / in.dt）
├─ doom.log:severity/error  闸门①阈值 → 组装并广播（唯一"会打字"的地方）
└─ doom.log:history/record  追加历史 + 环形上限 + 计数（**无论播不播都跑**）
```

**为什么 severity 里可以放心 `return`**：`return` 只结束**本函数**，标签会继续跑 `history/record`
—— 所以"阈值 / 冷却 / 静音"只影响出声，不影响记账。
（bs.log 同款结构：`#bs.log:error` = `[time/get, severity/error, history/record]` 三个函数的标签。）

## 三层 storage

| storage | 作用 | 键 |
|---|---|---|
| `doom.log:in` | **调用契约** | `code` `message` `path` `gt` `dt` |
| `doom.log:const` | 常量 | `cfg.cooldown`（冷却 tick）`cfg.cap`（历史上限） |
| `doom.log:data` | 状态 | `history[]` `by_code.<CODE>{n,t,message}` `last` |

## API

| 调用 | 说明 |
|---|---|
| `doom.log:error {code,message}` | 红色，所有人可见、**不可静音** |
| `doom.log:warn {code,message}` | 黄色，`tag @s add de.mute.warn` 可自静音 |
| `doom.log:info {code,message}` | 灰色，`tag @s add de.mute.info` 可自静音 |
| `doom.log:dump`（标签 `#doom.log:dump`） | 计数 + 每个 code 的次数/最近时刻/最近原文 + 最后一条 |
| `doom.log:clear` | 清空历史与计数 |
| `doom.log:__help__` | 本地手册（bs 只给网址，本包不依赖联网） |

**两条调用铁律**（引擎硬约束，本项目已钉）
1. `code` 与 `message` **两个键都必须写** —— 宏参数缺一个，**整个函数体被静默放弃**。
2. 参数值里**不要带引号** —— 宏替换会剥掉 NBT 字符串的引号；模板里已经写好引号，你给裸文本。

**第二入口（分区调用）**：自己写契约再调标签，可以带上"报告者路径"：

```
data modify storage doom.log:in.path set value "doom.xxx:yyy"
function #doom.log:warn
```
这条路**跳过 api 入口的去重与 by_code 记账**（code 得由宏带进路径）—— 需要计数就用推荐入口。

## 两道闸门

| 闸门 | 怎么调 | 说明 |
|---|---|---|
| ① 阈值 | `/scoreboard players set #min dl.log 1` | 1 = 只放 error，2 = +warn，3 = 全放（默认 3） |
| ② 同 code 冷却 | `doom.log:const cfg.cooldown`（默认 300 tick） | 同一 code 在窗口内重复**只记账不出声** —— 专治"每 tick 触发一次"的刷屏 |

## 编码约定

| 段 | 含义 | 例子 |
|---|---|---|
| **E1xx** | 配置 / 加载期 | `E101` 依赖的包没加载 |
| **E2xx** | 并发 / 状态污染 | `E201` 共享临时键残留 |
| **E3xx** | 持久层 / 缓存 | `E301` 恢复时缓存里没有物品 |
| **E4xx** | 物品 / NBT 契约 | `E401` 判据按 int 写了 byte |
| **E5xx** | 调度 / 时序 | `E501` 到点未执行 |
| **E9xx** | 其它 / 兼容路径 | `E901` 走了兼容分支 |

已接入：`doom.consumable:recover/tick_one`（E201）。

## 与 `bs.log` 的对照

**原样照抄**：函数标签即 API；三层 storage；`time → severity → history` 三段；环形历史；
`__help__`；严重度分档。

**刻意不抄（bs.log 的不足）**

| bs.log 的做法 | 问题 | 本包怎么改 |
|---|---|---|
| 常驻 `text_display` + `forceload` + 一个 `setblock` 命令方块，用来存"已格式化的 JSON 文本" | 一个日志模块往存档里塞常驻实体、常驻区块和一个来路不明的命令方块；实体一旦不在，`history/record` 会断 —— 而它挂在**每个** severity 标签上 ⇒ 日志模块自己把调用方拖下水 | 消息是纯字符串，storage 足够；**不用任何实体 / 方块 / schedule** |
| 每秒 `schedule` 维护时钟字符串，再用 `set string … 0 2` 切片 | 多一个常驻任务与中间态；reload 后首帧可能拿到旧值 | 直接记 `gametime` + "距上条日志的 tick"，对着 `latest.log` 的游戏事件看更好对齐 |
| 静音是「命名空间 × tag × severity」三维 + `_` 通配 ⇒ 每个 severity 文件里 20 条 `tag=!…` | 组合随包数立方增长；读代码看不出"到底谁能看到" | 砍成**档位级一维**：`de.mute.warn` / `de.mute.info`；error 永不可静音 |
| 格式表在 `__load__` 里按命名空间复制成多份大 JSON（每份重复 hover/时间戳模板） | 改一处要改多处，重复即 bug 源 | 一份模板 + 生成器 `tools/gen_log_severity.py` 产出三档 |
| **没有去重** | 同一个错误每 tick 触发就每 tick 刷一地 | **闸门②**：同 code 冷却窗口内只记账不出声 |
| **没有阈值** | 想"只留错误"只能靠组合 tag 逐个静音 | **闸门①**：一个分数 `#min` 全局切档 |
| **没有计数 / 索引** | 想知道"哪个坑最常踩"得自己翻 4096 条流水 | `by_code.<CODE>{n,t,message}` + `dump` 一眼看完 |
| `help` 只给网址 | 离线环境等于没有 | `__help__` 本地打印用法与约定 |
| 调用方必须传 `namespace/tag/path` | 写日志比写业务代码还长 | 推荐入口只要 `{code,message}`；要精确路径走分区入口 |

**代价（诚实记下来）**：没有格式表插值 —— 消息是纯文本 + 固定 hover，
消息里要带数字请自己在 `message` 文本里拼（不支持像 bs 那样嵌任意组件）。

## 怎么验证

```
/reload                        → 聊天栏出现 [doom.log] loaded
/function doom.log:dump        → 汇总（刚加载时全 0）
/function doom.log:__help__    → 本地手册
/function doom.test:run        → 全套断言里含 suite/log_core（静默跑，专盯两道闸门与记账）
```
